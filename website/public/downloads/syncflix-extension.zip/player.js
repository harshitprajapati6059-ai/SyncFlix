"use strict";
(() => {
  // src/messages.ts
  var NETFLIX_CMD_TYPE = "SYNCFLIX_NETFLIX_CMD";
  var PLAYER_PORT = "player";

  // src/adapters/netflix.ts
  function command(action, timeMs) {
    const msg = { type: NETFLIX_CMD_TYPE, action, timeMs };
    window.postMessage(msg, window.location.origin);
  }
  function parseVideoId(loc) {
    const match = loc.pathname.match(/^\/watch\/(\d+)/);
    return match ? match[1] : null;
  }
  var netflixAdapter = {
    platform: "Netflix",
    matches(hostname) {
      return /(^|\.)netflix\.com$/.test(hostname);
    },
    findVideo() {
      if (!parseVideoId(window.location)) return null;
      return document.querySelector(".watch-video video") ?? document.querySelector("video");
    },
    getVideoInfo() {
      const videoId = parseVideoId(window.location);
      return {
        videoId,
        videoUrl: videoId ? `https://www.netflix.com/watch/${videoId}` : null
      };
    },
    onNavigation(callback) {
      window.addEventListener("popstate", callback);
    },
    seek(seconds) {
      command("seek", Math.round(seconds * 1e3));
    },
    play() {
      command("play");
    },
    pause() {
      command("pause");
    },
    // Netflix re-asserts its own playback rate, so a ±5 % drift nudge either gets
    // wiped (no correction) or sticks (permanent drift). Drift is corrected by
    // seeking instead.
    canNudgeRate: false
  };

  // src/adapters/primevideo.ts
  var HOST_PATTERN = /(^|\.)(primevideo\.com|amazon\.(com|ca|com\.br|com\.mx|co\.uk|de|fr|it|es|nl|se|pl|com\.tr|ae|sa|in|sg|co\.jp|com\.au))$/;
  var PLAYER_CONTAINERS = [
    ".webPlayerSDKContainer",
    ".webPlayerElement",
    "#dv-web-player",
    ".dv-player-fullscreen"
  ];
  var AD_MARKERS = [
    ".atvwebplayersdk-adtimeindicator-text",
    ".atvwebplayersdk-ad-timer-remaining-time",
    ".atvwebplayersdk-adbadge-text",
    ".atvwebplayersdk-adskipbutton-button",
    '[data-testid="ad-timer"]',
    '[data-testid="ad-badge"]'
  ];
  function visible(selector) {
    const el = document.querySelector(selector);
    return !!el && el.getClientRects().length > 0;
  }
  function parseVideoId2(loc) {
    const params = new URLSearchParams(loc.search);
    const param = params.get("asin") ?? params.get("gti");
    if (param) return param;
    const match = loc.pathname.match(/\/(?:detail|dp)\/([A-Za-z0-9]{8,})/);
    return match ? match[1] : null;
  }
  var primeVideoAdapter = {
    platform: "Prime Video",
    matches(hostname) {
      return HOST_PATTERN.test(hostname);
    },
    findVideo() {
      for (const container of PLAYER_CONTAINERS) {
        const video2 = document.querySelector(`${container} video`);
        if (video2) return video2;
      }
      return null;
    },
    getVideoInfo() {
      const videoId = parseVideoId2(window.location);
      if (!videoId) return { videoId: null, videoUrl: null };
      const path = window.location.pathname.includes("/gp/video/") ? `/gp/video/detail/${videoId}` : `/detail/${videoId}`;
      return { videoId, videoUrl: `${window.location.origin}${path}` };
    },
    onNavigation(callback) {
      window.addEventListener("popstate", callback);
    },
    isAdPlaying() {
      return AD_MARKERS.some(visible);
    }
  };

  // src/adapters/youtube.ts
  function parseVideoId3(loc) {
    const v = new URLSearchParams(loc.search).get("v");
    if (v) return v;
    const match = loc.pathname.match(/^\/(?:shorts|embed|live)\/([\w-]{6,})/);
    return match ? match[1] : null;
  }
  var youtubeAdapter = {
    platform: "YouTube",
    matches(hostname) {
      return /(^|\.)youtube\.com$/.test(hostname);
    },
    findVideo() {
      return document.querySelector("video.html5-main-video") ?? document.querySelector("#movie_player video");
    },
    getVideoInfo() {
      const videoId = parseVideoId3(window.location);
      return {
        videoId,
        // Canonical watch URL — shorts/embed ids play fine on the watch page.
        videoUrl: videoId ? `https://www.youtube.com/watch?v=${videoId}` : null
      };
    },
    onNavigation(callback) {
      document.addEventListener("yt-navigate-finish", callback);
    }
  };

  // src/player.ts
  var ADAPTERS = [youtubeAdapter, netflixAdapter, primeVideoAdapter];
  var INERT_ADAPTER = {
    platform: "Unknown",
    matches: () => false,
    findVideo: () => null,
    getVideoInfo: () => ({ videoId: null, videoUrl: null }),
    onNavigation: () => void 0
  };
  var adapter = ADAPTERS.find((a) => a.matches(location.hostname)) ?? INERT_ADAPTER;
  var RECONNECT_DELAY_MS = 1e3;
  var VIDEO_POLL_MS = 1e3;
  var POSITION_REPORT_MS = 1e3;
  var SEEK_TOLERANCE_S = 1;
  var DRIFT_MIN_S = 0.5;
  var DRIFT_MAX_S = 3;
  var NUDGE_DONE_S = 0.15;
  var NUDGE_FACTOR = 0.05;
  var NUDGE_MAX_MS = 15e3;
  var ECHO_WINDOW_MS = 1e3;
  var SEEK_ECHO_WINDOW_MS = 5e3;
  var SEEK_MATCH_TOLERANCE_S = 1.5;
  var SEEK_SETTLE_MS = 1500;
  var REMOTE_TARGET_MEMORY_MS = 5e3;
  var AD_TRANSITION_QUIET_MS = 2e3;
  var port = null;
  function connect() {
    try {
      port = chrome.runtime.connect({ name: PLAYER_PORT });
    } catch {
      port = null;
      return;
    }
    port.onMessage.addListener((msg) => {
      if (msg.type === "SYNC_EVENT") applyRemote(msg.payload);
    });
    port.onDisconnect.addListener(() => {
      port = null;
      window.setTimeout(() => {
        connect();
        announceAttachment();
      }, RECONNECT_DELAY_MS);
    });
  }
  function sendSync(event, payload) {
    const envelope = {
      event,
      payload: { ...payload, videoId: currentVideo.videoId, videoUrl: currentVideo.videoUrl }
    };
    port?.postMessage({ type: "SYNC_EVENT", payload: envelope });
  }
  function announceAttachment() {
    if (video) {
      port?.postMessage({
        type: "ADAPTER_ATTACHED",
        payload: {
          platform: adapter.platform,
          videoId: currentVideo.videoId,
          videoUrl: currentVideo.videoUrl
        }
      });
    } else {
      port?.postMessage({ type: "ADAPTER_LOST" });
    }
  }
  var quietUntil = 0;
  var pendingSeek = null;
  var remoteTarget = null;
  function beQuiet(ms) {
    quietUntil = Math.max(quietUntil, Date.now() + ms);
  }
  function seekPending() {
    if (pendingSeek && Date.now() > pendingSeek.expires) pendingSeek = null;
    return pendingSeek !== null;
  }
  function isEcho() {
    return seekPending() || Date.now() < quietUntil;
  }
  function noteRemoteTarget(seconds) {
    remoteTarget = { time: seconds, at: Date.now() };
  }
  function isRemoteTarget(position) {
    if (!remoteTarget) return false;
    const age = Date.now() - remoteTarget.at;
    if (age > REMOTE_TARGET_MEMORY_MS) return false;
    const advanced = video && !video.paused ? remoteTarget.time + age / 1e3 * video.playbackRate : remoteTarget.time;
    return Math.abs(position - advanced) <= SEEK_MATCH_TOLERANCE_S;
  }
  var inAd = false;
  function adBreak() {
    return inAd;
  }
  function pollAdState() {
    const now = adapter.isAdPlaying?.() === true;
    if (now === inAd) return;
    inAd = now;
    beQuiet(AD_TRANSITION_QUIET_MS);
    pendingSeek = null;
    remoteTarget = null;
    if (video) lastTime = video.currentTime;
  }
  function seekTo(v, seconds) {
    pendingSeek = { target: seconds, expires: Date.now() + SEEK_ECHO_WINDOW_MS };
    noteRemoteTarget(seconds);
    beQuiet(ECHO_WINDOW_MS);
    if (adapter.seek) adapter.seek(seconds);
    else v.currentTime = seconds;
  }
  function playVideo(v) {
    beQuiet(ECHO_WINDOW_MS);
    if (adapter.play) adapter.play();
    else void v.play().catch(() => void 0);
  }
  function pauseVideo(v) {
    beQuiet(ECHO_WINDOW_MS);
    if (adapter.pause) adapter.pause();
    else v.pause();
  }
  function setRate(v, rate) {
    beQuiet(ECHO_WINDOW_MS);
    v.playbackRate = rate;
  }
  var baseRate = 1;
  var nudging = false;
  var nudgeStartedAt = 0;
  var canNudge = adapter.canNudgeRate !== false;
  function endNudge(v) {
    if (!nudging) return;
    nudging = false;
    if (v.playbackRate !== baseRate) setRate(v, baseRate);
  }
  function applyRemote({ event, payload }) {
    if (!video) return;
    if (adBreak()) return;
    const remoteVideoId = payload.videoId;
    if (typeof remoteVideoId === "string" && currentVideo.videoId !== null && remoteVideoId !== currentVideo.videoId) {
      return;
    }
    const v = video;
    switch (event) {
      case "PLAY": {
        const t = payload.currentTime;
        if (typeof t === "number") alignTo(v, t);
        if (v.paused) playVideo(v);
        break;
      }
      case "PAUSE": {
        if (!v.paused) pauseVideo(v);
        const t = payload.currentTime;
        if (typeof t === "number") alignTo(v, t);
        break;
      }
      case "SEEK": {
        const to = payload.to;
        if (typeof to === "number") alignTo(v, to);
        break;
      }
      case "PLAYBACK_SPEED": {
        const rate = payload.rate;
        if (typeof rate === "number") {
          baseRate = rate;
          if (!nudging && v.playbackRate !== rate) setRate(v, rate);
        }
        break;
      }
      case "POSITION_UPDATE":
        onHostHeartbeat(v, payload);
        break;
    }
  }
  function alignTo(v, target) {
    if (Math.abs(v.currentTime - target) > SEEK_TOLERANCE_S) seekTo(v, target);
    else noteRemoteTarget(target);
  }
  function onHostHeartbeat(v, payload) {
    const hostTime = payload.currentTime;
    if (typeof hostTime !== "number") return;
    const hostPlaying = Boolean(payload.playing);
    if (seekPending() || v.seeking) return;
    if (hostPlaying === v.paused) {
      if (hostPlaying) playVideo(v);
      else pauseVideo(v);
    }
    const drift = v.currentTime - hostTime;
    const abs = Math.abs(drift);
    if (!hostPlaying) {
      if (abs > SEEK_TOLERANCE_S) seekTo(v, hostTime);
      endNudge(v);
      return;
    }
    if (abs > DRIFT_MAX_S) {
      seekTo(v, hostTime);
      endNudge(v);
    } else if (!canNudge) {
    } else if (abs > DRIFT_MIN_S) {
      if (!nudging) {
        nudging = true;
        nudgeStartedAt = Date.now();
      } else if (Date.now() - nudgeStartedAt > NUDGE_MAX_MS) {
        endNudge(v);
        return;
      }
      const target = drift > 0 ? baseRate * (1 - NUDGE_FACTOR) : baseRate * (1 + NUDGE_FACTOR);
      if (v.playbackRate !== target) v.playbackRate = target;
    } else if (nudging && abs < NUDGE_DONE_S) {
      endNudge(v);
    }
  }
  var lastTime = 0;
  function onPlay() {
    pollAdState();
    if (!video || adBreak() || isEcho()) return;
    sendSync("PLAY", { currentTime: video.currentTime, platform: adapter.platform });
  }
  function onPause() {
    pollAdState();
    if (!video || adBreak() || isEcho()) return;
    sendSync("PAUSE", { currentTime: video.currentTime });
  }
  function onSeeked() {
    pollAdState();
    if (!video || adBreak()) return;
    const from = lastTime;
    const to = video.currentTime;
    lastTime = to;
    if (seekPending()) {
      if (Math.abs(to - pendingSeek.target) <= SEEK_MATCH_TOLERANCE_S) {
        pendingSeek = null;
        beQuiet(SEEK_SETTLE_MS);
      }
      return;
    }
    if (Date.now() < quietUntil) return;
    if (isRemoteTarget(to)) return;
    sendSync("SEEK", { from, to });
  }
  function onRateChange() {
    pollAdState();
    if (!video || adBreak() || nudging || isEcho()) return;
    baseRate = video.playbackRate;
    sendSync("PLAYBACK_SPEED", { rate: video.playbackRate });
  }
  function onTimeUpdate() {
    if (video && !video.seeking && !adBreak()) lastTime = video.currentTime;
  }
  var video = null;
  var currentVideo = { videoId: null, videoUrl: null };
  function attach(v) {
    v.addEventListener("play", onPlay);
    v.addEventListener("pause", onPause);
    v.addEventListener("seeked", onSeeked);
    v.addEventListener("ratechange", onRateChange);
    v.addEventListener("timeupdate", onTimeUpdate);
    lastTime = v.currentTime;
    baseRate = v.playbackRate;
    nudging = false;
    pendingSeek = null;
    remoteTarget = null;
    quietUntil = 0;
  }
  function detach(v) {
    v.removeEventListener("play", onPlay);
    v.removeEventListener("pause", onPause);
    v.removeEventListener("seeked", onSeeked);
    v.removeEventListener("ratechange", onRateChange);
    v.removeEventListener("timeupdate", onTimeUpdate);
  }
  function checkVideo() {
    const found = adapter.findVideo();
    const info = adapter.getVideoInfo();
    const elementChanged = found !== video;
    const videoChanged = info.videoId !== currentVideo.videoId;
    if (!elementChanged && !videoChanged) return;
    if (elementChanged) {
      if (video) detach(video);
      video = found;
      if (video) attach(video);
    }
    currentVideo = info;
    announceAttachment();
  }
  adapter.onNavigation(checkVideo);
  window.setInterval(checkVideo, VIDEO_POLL_MS);
  window.setInterval(() => {
    pollAdState();
    if (!video || adBreak()) return;
    sendSync("POSITION_UPDATE", { currentTime: video.currentTime, playing: !video.paused });
  }, POSITION_REPORT_MS);
  connect();
  checkVideo();
})();
