"use strict";
(() => {
  // src/messages.ts
  var NETFLIX_SEEK_TYPE = "SYNCFLIX_NETFLIX_SEEK";
  var PLAYER_PORT = "player";

  // src/adapters/netflix.ts
  function parseVideoId(loc) {
    const match = loc.pathname.match(/^\/watch\/(\d+)/);
    return match ? match[1] : null;
  }
  var netflixAdapter = {
    platform: "Netflix",
    findVideo() {
      if (!parseVideoId(window.location)) return null;
      return document.querySelector(".watch-video video") ?? document.querySelector("video");
    },
    getVideoInfo() {
      const videoId = parseVideoId(window.location);
      return {
        videoId,
        videoUrl: videoId ? `https://www.netflix.com/watch/${videoId}` : null
      };
    },
    onNavigation(callback) {
      window.addEventListener("popstate", callback);
    },
    seek(seconds) {
      const msg = {
        type: NETFLIX_SEEK_TYPE,
        timeMs: Math.round(seconds * 1e3)
      };
      window.postMessage(msg, window.location.origin);
    }
  };

  // src/adapters/youtube.ts
  function parseVideoId2(loc) {
    const v = new URLSearchParams(loc.search).get("v");
    if (v) return v;
    const match = loc.pathname.match(/^\/(?:shorts|embed|live)\/([\w-]{6,})/);
    return match ? match[1] : null;
  }
  var youtubeAdapter = {
    platform: "YouTube",
    findVideo() {
      return document.querySelector("video.html5-main-video") ?? document.querySelector("#movie_player video");
    },
    getVideoInfo() {
      const videoId = parseVideoId2(window.location);
      return {
        videoId,
        // Canonical watch URL — shorts/embed ids play fine on the watch page.
        videoUrl: videoId ? `https://www.youtube.com/watch?v=${videoId}` : null
      };
    },
    onNavigation(callback) {
      document.addEventListener("yt-navigate-finish", callback);
    }
  };

  // src/player.ts
  var adapter = location.hostname.endsWith("netflix.com") ? netflixAdapter : youtubeAdapter;
  var RECONNECT_DELAY_MS = 1e3;
  var VIDEO_POLL_MS = 1e3;
  var POSITION_REPORT_MS = 1e3;
  var EXPECTATION_TTL_MS = 800;
  var SEEK_TOLERANCE_S = 1;
  var DRIFT_MIN_S = 0.5;
  var DRIFT_MAX_S = 3;
  var NUDGE_DONE_S = 0.15;
  var NUDGE_FACTOR = 0.05;
  var port = null;
  function connect() {
    try {
      port = chrome.runtime.connect({ name: PLAYER_PORT });
    } catch {
      port = null;
      return;
    }
    port.onMessage.addListener((msg) => {
      if (msg.type === "SYNC_EVENT") applyRemote(msg.payload);
    });
    port.onDisconnect.addListener(() => {
      port = null;
      window.setTimeout(() => {
        connect();
        announceAttachment();
      }, RECONNECT_DELAY_MS);
    });
  }
  function sendSync(event, payload) {
    const envelope = {
      event,
      payload: { ...payload, videoId: currentVideo.videoId, videoUrl: currentVideo.videoUrl }
    };
    port?.postMessage({ type: "SYNC_EVENT", payload: envelope });
  }
  function announceAttachment() {
    if (video) {
      port?.postMessage({
        type: "ADAPTER_ATTACHED",
        payload: {
          platform: adapter.platform,
          videoId: currentVideo.videoId,
          videoUrl: currentVideo.videoUrl
        }
      });
    } else {
      port?.postMessage({ type: "ADAPTER_LOST" });
    }
  }
  var expectations = [];
  function expect(action) {
    expectations.push({ action, expires: Date.now() + EXPECTATION_TTL_MS });
  }
  function seekTo(v, seconds) {
    expect("seek");
    if (adapter.seek) adapter.seek(seconds);
    else v.currentTime = seconds;
  }
  function consumeExpectation(action) {
    const now = Date.now();
    for (let i = expectations.length - 1; i >= 0; i--) {
      if (expectations[i].expires < now) expectations.splice(i, 1);
    }
    const idx = expectations.findIndex((e) => e.action === action);
    if (idx === -1) return false;
    expectations.splice(idx, 1);
    return true;
  }
  var baseRate = 1;
  var nudging = false;
  function endNudge(v) {
    if (!nudging) return;
    nudging = false;
    if (v.playbackRate !== baseRate) {
      expect("rate");
      v.playbackRate = baseRate;
    }
  }
  function applyRemote({ event, payload }) {
    if (!video) return;
    const remoteVideoId = payload.videoId;
    if (typeof remoteVideoId === "string" && currentVideo.videoId !== null && remoteVideoId !== currentVideo.videoId) {
      return;
    }
    const v = video;
    switch (event) {
      case "PLAY": {
        const t = payload.currentTime;
        if (typeof t === "number" && Math.abs(v.currentTime - t) > SEEK_TOLERANCE_S) {
          seekTo(v, t);
        }
        if (v.paused) {
          expect("play");
          void v.play();
        }
        break;
      }
      case "PAUSE": {
        if (!v.paused) {
          expect("pause");
          v.pause();
        }
        const t = payload.currentTime;
        if (typeof t === "number" && Math.abs(v.currentTime - t) > SEEK_TOLERANCE_S) {
          seekTo(v, t);
        }
        break;
      }
      case "SEEK": {
        const to = payload.to;
        if (typeof to === "number") {
          seekTo(v, to);
        }
        break;
      }
      case "PLAYBACK_SPEED": {
        const rate = payload.rate;
        if (typeof rate === "number") {
          baseRate = rate;
          if (!nudging && v.playbackRate !== rate) {
            expect("rate");
            v.playbackRate = rate;
          }
        }
        break;
      }
      case "POSITION_UPDATE":
        onHostHeartbeat(v, payload);
        break;
    }
  }
  function onHostHeartbeat(v, payload) {
    const hostTime = payload.currentTime;
    if (typeof hostTime !== "number") return;
    const hostPlaying = Boolean(payload.playing);
    if (hostPlaying === v.paused) {
      if (hostPlaying) {
        expect("play");
        void v.play();
      } else {
        expect("pause");
        v.pause();
      }
    }
    const drift = v.currentTime - hostTime;
    const abs = Math.abs(drift);
    if (!hostPlaying) {
      if (abs > SEEK_TOLERANCE_S) {
        seekTo(v, hostTime);
      }
      endNudge(v);
      return;
    }
    if (abs > DRIFT_MAX_S) {
      seekTo(v, hostTime);
      endNudge(v);
    } else if (abs > DRIFT_MIN_S) {
      nudging = true;
      const target = drift > 0 ? baseRate * (1 - NUDGE_FACTOR) : baseRate * (1 + NUDGE_FACTOR);
      if (v.playbackRate !== target) v.playbackRate = target;
    } else if (nudging && abs < NUDGE_DONE_S) {
      endNudge(v);
    }
  }
  var lastTime = 0;
  function onPlay() {
    if (!video || consumeExpectation("play")) return;
    sendSync("PLAY", { currentTime: video.currentTime, platform: adapter.platform });
  }
  function onPause() {
    if (!video || consumeExpectation("pause")) return;
    sendSync("PAUSE", { currentTime: video.currentTime });
  }
  function onSeeked() {
    if (!video) return;
    const from = lastTime;
    const to = video.currentTime;
    lastTime = to;
    if (consumeExpectation("seek")) return;
    sendSync("SEEK", { from, to });
  }
  function onRateChange() {
    if (!video || nudging || consumeExpectation("rate")) return;
    baseRate = video.playbackRate;
    sendSync("PLAYBACK_SPEED", { rate: video.playbackRate });
  }
  function onTimeUpdate() {
    if (video && !video.seeking) lastTime = video.currentTime;
  }
  var video = null;
  var currentVideo = { videoId: null, videoUrl: null };
  function attach(v) {
    v.addEventListener("play", onPlay);
    v.addEventListener("pause", onPause);
    v.addEventListener("seeked", onSeeked);
    v.addEventListener("ratechange", onRateChange);
    v.addEventListener("timeupdate", onTimeUpdate);
    lastTime = v.currentTime;
    baseRate = v.playbackRate;
    nudging = false;
  }
  function detach(v) {
    v.removeEventListener("play", onPlay);
    v.removeEventListener("pause", onPause);
    v.removeEventListener("seeked", onSeeked);
    v.removeEventListener("ratechange", onRateChange);
    v.removeEventListener("timeupdate", onTimeUpdate);
  }
  function checkVideo() {
    const found = adapter.findVideo();
    const info = adapter.getVideoInfo();
    const elementChanged = found !== video;
    const videoChanged = info.videoId !== currentVideo.videoId;
    if (!elementChanged && !videoChanged) return;
    if (elementChanged) {
      if (video) detach(video);
      video = found;
      if (video) attach(video);
    }
    currentVideo = info;
    announceAttachment();
  }
  adapter.onNavigation(checkVideo);
  window.setInterval(checkVideo, VIDEO_POLL_MS);
  window.setInterval(() => {
    if (!video) return;
    sendSync("POSITION_UPDATE", { currentTime: video.currentTime, playing: !video.paused });
  }, POSITION_REPORT_MS);
  connect();
  checkVideo();
})();
