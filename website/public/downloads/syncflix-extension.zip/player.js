"use strict";
(() => {
  // src/adapters/youtube.ts
  var youtubeAdapter = {
    platform: "YouTube",
    findVideo() {
      return document.querySelector("video.html5-main-video") ?? document.querySelector("#movie_player video");
    },
    onNavigation(callback) {
      document.addEventListener("yt-navigate-finish", callback);
    }
  };

  // src/messages.ts
  var PLAYER_PORT = "player";

  // src/player.ts
  var adapter = youtubeAdapter;
  var RECONNECT_DELAY_MS = 1e3;
  var VIDEO_POLL_MS = 1e3;
  var POSITION_REPORT_MS = 1e3;
  var EXPECTATION_TTL_MS = 800;
  var SEEK_TOLERANCE_S = 1;
  var DRIFT_MIN_S = 0.5;
  var DRIFT_MAX_S = 3;
  var NUDGE_DONE_S = 0.15;
  var NUDGE_FACTOR = 0.05;
  var port = null;
  function connect() {
    try {
      port = chrome.runtime.connect({ name: PLAYER_PORT });
    } catch {
      port = null;
      return;
    }
    port.onMessage.addListener((msg) => {
      if (msg.type === "SYNC_EVENT") applyRemote(msg.payload);
    });
    port.onDisconnect.addListener(() => {
      port = null;
      window.setTimeout(() => {
        connect();
        announceAttachment();
      }, RECONNECT_DELAY_MS);
    });
  }
  function sendSync(event, payload) {
    const envelope = { event, payload };
    port?.postMessage({ type: "SYNC_EVENT", payload: envelope });
  }
  function announceAttachment() {
    if (video) {
      port?.postMessage({
        type: "ADAPTER_ATTACHED",
        payload: { platform: adapter.platform }
      });
    } else {
      port?.postMessage({ type: "ADAPTER_LOST" });
    }
  }
  var expectations = [];
  function expect(action) {
    expectations.push({ action, expires: Date.now() + EXPECTATION_TTL_MS });
  }
  function consumeExpectation(action) {
    const now = Date.now();
    for (let i = expectations.length - 1; i >= 0; i--) {
      if (expectations[i].expires < now) expectations.splice(i, 1);
    }
    const idx = expectations.findIndex((e) => e.action === action);
    if (idx === -1) return false;
    expectations.splice(idx, 1);
    return true;
  }
  var baseRate = 1;
  var nudging = false;
  function endNudge(v) {
    if (!nudging) return;
    nudging = false;
    if (v.playbackRate !== baseRate) {
      expect("rate");
      v.playbackRate = baseRate;
    }
  }
  function applyRemote({ event, payload }) {
    if (!video) return;
    const v = video;
    switch (event) {
      case "PLAY": {
        const t = payload.currentTime;
        if (typeof t === "number" && Math.abs(v.currentTime - t) > SEEK_TOLERANCE_S) {
          expect("seek");
          v.currentTime = t;
        }
        if (v.paused) {
          expect("play");
          void v.play();
        }
        break;
      }
      case "PAUSE": {
        if (!v.paused) {
          expect("pause");
          v.pause();
        }
        const t = payload.currentTime;
        if (typeof t === "number" && Math.abs(v.currentTime - t) > SEEK_TOLERANCE_S) {
          expect("seek");
          v.currentTime = t;
        }
        break;
      }
      case "SEEK": {
        const to = payload.to;
        if (typeof to === "number") {
          expect("seek");
          v.currentTime = to;
        }
        break;
      }
      case "PLAYBACK_SPEED": {
        const rate = payload.rate;
        if (typeof rate === "number") {
          baseRate = rate;
          if (!nudging && v.playbackRate !== rate) {
            expect("rate");
            v.playbackRate = rate;
          }
        }
        break;
      }
      case "POSITION_UPDATE":
        onHostHeartbeat(v, payload);
        break;
    }
  }
  function onHostHeartbeat(v, payload) {
    const hostTime = payload.currentTime;
    if (typeof hostTime !== "number") return;
    const hostPlaying = Boolean(payload.playing);
    if (hostPlaying === v.paused) {
      if (hostPlaying) {
        expect("play");
        void v.play();
      } else {
        expect("pause");
        v.pause();
      }
    }
    const drift = v.currentTime - hostTime;
    const abs = Math.abs(drift);
    if (!hostPlaying) {
      if (abs > SEEK_TOLERANCE_S) {
        expect("seek");
        v.currentTime = hostTime;
      }
      endNudge(v);
      return;
    }
    if (abs > DRIFT_MAX_S) {
      expect("seek");
      v.currentTime = hostTime;
      endNudge(v);
    } else if (abs > DRIFT_MIN_S) {
      nudging = true;
      const target = drift > 0 ? baseRate * (1 - NUDGE_FACTOR) : baseRate * (1 + NUDGE_FACTOR);
      if (v.playbackRate !== target) v.playbackRate = target;
    } else if (nudging && abs < NUDGE_DONE_S) {
      endNudge(v);
    }
  }
  var lastTime = 0;
  function onPlay() {
    if (!video || consumeExpectation("play")) return;
    sendSync("PLAY", { currentTime: video.currentTime, platform: adapter.platform });
  }
  function onPause() {
    if (!video || consumeExpectation("pause")) return;
    sendSync("PAUSE", { currentTime: video.currentTime });
  }
  function onSeeked() {
    if (!video) return;
    const from = lastTime;
    const to = video.currentTime;
    lastTime = to;
    if (consumeExpectation("seek")) return;
    sendSync("SEEK", { from, to });
  }
  function onRateChange() {
    if (!video || nudging || consumeExpectation("rate")) return;
    baseRate = video.playbackRate;
    sendSync("PLAYBACK_SPEED", { rate: video.playbackRate });
  }
  function onTimeUpdate() {
    if (video && !video.seeking) lastTime = video.currentTime;
  }
  var video = null;
  function attach(v) {
    v.addEventListener("play", onPlay);
    v.addEventListener("pause", onPause);
    v.addEventListener("seeked", onSeeked);
    v.addEventListener("ratechange", onRateChange);
    v.addEventListener("timeupdate", onTimeUpdate);
    lastTime = v.currentTime;
    baseRate = v.playbackRate;
    nudging = false;
  }
  function detach(v) {
    v.removeEventListener("play", onPlay);
    v.removeEventListener("pause", onPause);
    v.removeEventListener("seeked", onSeeked);
    v.removeEventListener("ratechange", onRateChange);
    v.removeEventListener("timeupdate", onTimeUpdate);
  }
  function checkVideo() {
    const found = adapter.findVideo();
    if (found === video) return;
    if (video) detach(video);
    video = found;
    if (video) attach(video);
    announceAttachment();
  }
  adapter.onNavigation(checkVideo);
  window.setInterval(checkVideo, VIDEO_POLL_MS);
  window.setInterval(() => {
    if (!video) return;
    sendSync("POSITION_UPDATE", { currentTime: video.currentTime, playing: !video.paused });
  }, POSITION_REPORT_MS);
  connect();
  checkVideo();
})();
