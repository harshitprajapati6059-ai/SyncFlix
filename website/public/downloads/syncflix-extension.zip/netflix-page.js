"use strict";
(() => {
  // src/messages.ts
  var NETFLIX_CMD_TYPE = "SYNCFLIX_NETFLIX_CMD";

  // src/netflix-page.ts
  function getVideoPlayer() {
    const netflixGlobal = window.netflix;
    const videoPlayer = netflixGlobal?.appContext?.state?.playerApp?.getAPI?.()?.videoPlayer;
    if (!videoPlayer) return null;
    const ids = videoPlayer.getAllPlayerSessionIds();
    const sessionId = ids.find((id) => id.startsWith("watch-")) ?? ids[0];
    return sessionId ? videoPlayer.getVideoPlayerBySessionId(sessionId) : null;
  }
  function watchVideo() {
    return document.querySelector(".watch-video video");
  }
  function fallback(msg) {
    const video = watchVideo();
    if (!video) return;
    if (msg.action === "seek" && typeof msg.timeMs === "number")
      video.currentTime = msg.timeMs / 1e3;
    else if (msg.action === "play") void video.play().catch(() => void 0);
    else if (msg.action === "pause") video.pause();
  }
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const msg = event.data;
    if (msg?.type !== NETFLIX_CMD_TYPE) return;
    if (msg.action !== "seek" && msg.action !== "play" && msg.action !== "pause") return;
    if (msg.action === "seek" && typeof msg.timeMs !== "number") return;
    const command = msg;
    try {
      const player = getVideoPlayer();
      if (player) {
        if (command.action === "seek") player.seek(command.timeMs);
        else if (command.action === "play") player.play();
        else player.pause();
        return;
      }
    } catch {
    }
    fallback(command);
  });
})();
