"use strict";
(() => {
  // src/messages.ts
  var NETFLIX_SEEK_TYPE = "SYNCFLIX_NETFLIX_SEEK";

  // src/netflix-page.ts
  function getVideoPlayer() {
    const netflixGlobal = window.netflix;
    const videoPlayer = netflixGlobal?.appContext?.state?.playerApp?.getAPI?.()?.videoPlayer;
    if (!videoPlayer) return null;
    const ids = videoPlayer.getAllPlayerSessionIds();
    const sessionId = ids.find((id) => id.startsWith("watch-")) ?? ids[0];
    return sessionId ? videoPlayer.getVideoPlayerBySessionId(sessionId) : null;
  }
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const msg = event.data;
    if (msg?.type !== NETFLIX_SEEK_TYPE || typeof msg.timeMs !== "number") return;
    try {
      const player = getVideoPlayer();
      if (player) {
        player.seek(msg.timeMs);
        return;
      }
    } catch {
    }
    const video = document.querySelector(".watch-video video");
    if (video) video.currentTime = msg.timeMs / 1e3;
  });
})();
