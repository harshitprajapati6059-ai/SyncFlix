"use strict";
(() => {
  // src/messages.ts
  var PAGE_SOURCE = "syncflix-page";
  var EXT_SOURCE = "syncflix-ext";
  var PROTOCOL_VERSION = 1;
  var BRIDGE_PORT = "bridge";

  // src/bridge.ts
  var RECONNECT_DELAY_MS = 1e3;
  var port = null;
  function postToPage(type, payload) {
    const envelope = { source: EXT_SOURCE, v: PROTOCOL_VERSION, type, payload };
    window.postMessage(envelope, window.location.origin);
  }
  function connect() {
    try {
      port = chrome.runtime.connect({ name: BRIDGE_PORT });
    } catch {
      port = null;
      return;
    }
    port.onMessage.addListener((msg) => {
      if (msg.type === "EXTENSION_STATE") {
        postToPage("EXTENSION_STATE", msg.payload);
      } else if (msg.type === "SYNC_EVENT") {
        postToPage("SYNC_EVENT", msg.payload);
      }
    });
    port.onDisconnect.addListener(() => {
      port = null;
      postToPage("EXTENSION_STATE", { status: "waiting", platform: null, version: "" });
      window.setTimeout(connect, RECONNECT_DELAY_MS);
    });
    port.postMessage({ type: "GET_STATE" });
  }
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.source !== PAGE_SOURCE) return;
    if (data.type === "EXTENSION_PING") {
      postToPage("EXTENSION_HELLO", { version: chrome.runtime.getManifest().version });
      if (port) {
        port.postMessage({ type: "GET_STATE" });
      } else {
        connect();
      }
    } else if (data.type === "SYNC_EVENT") {
      port?.postMessage({ type: "SYNC_EVENT", payload: data.payload });
    } else if (data.type === "HOST_VIDEO") {
      const { url } = data.payload ?? {};
      port?.postMessage({ type: "HOST_VIDEO", payload: { url: url ?? null } });
    }
  });
  connect();
})();
