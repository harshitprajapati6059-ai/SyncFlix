"use strict";
(() => {
  // src/popup.ts
  function render(state) {
    const status = document.getElementById("status");
    const platform = document.getElementById("platform");
    const version = document.getElementById("version");
    if (!state) {
      status.textContent = "unavailable";
      return;
    }
    status.textContent = state.status === "connected" ? "connected" : "waiting for video";
    status.className = state.status;
    platform.textContent = state.platform ?? "\u2014";
    version.textContent = state.version;
  }
  chrome.runtime.sendMessage({ type: "GET_STATE" }, render);
})();
