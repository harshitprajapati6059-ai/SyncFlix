"use strict";
(() => {
  // src/popup.ts
  function render(state) {
    const status = document.getElementById("status");
    const platform = document.getElementById("platform");
    const version = document.getElementById("version");
    const roomTabs = document.getElementById("roomTabs");
    const playerTabs = document.getElementById("playerTabs");
    if (!state) {
      status.textContent = "unavailable";
      return;
    }
    status.textContent = state.status === "connected" ? "connected" : "waiting for video";
    status.className = state.status;
    platform.textContent = state.platform ?? "\u2014";
    version.textContent = state.version;
    roomTabs.textContent = state.roomTabs > 0 ? `${state.roomTabs} connected` : "none open";
    roomTabs.className = state.roomTabs > 0 ? "connected" : "waiting";
    playerTabs.textContent = state.playerTabs > 0 ? `${state.playerTabs} connected` : "none open";
    playerTabs.className = state.playerTabs > 0 ? "connected" : "waiting";
    const openRow = document.getElementById("openVideoRow");
    const openLink = document.getElementById("openVideo");
    const alreadyOnIt = state.hostVideoUrl !== null && state.videoUrl === state.hostVideoUrl;
    if (state.hostVideoUrl && !alreadyOnIt) {
      openRow.style.display = "";
      openLink.onclick = (e) => {
        e.preventDefault();
        void chrome.tabs.create({ url: state.hostVideoUrl });
      };
    } else {
      openRow.style.display = "none";
    }
  }
  chrome.runtime.sendMessage({ type: "GET_STATE" }, render);
})();
