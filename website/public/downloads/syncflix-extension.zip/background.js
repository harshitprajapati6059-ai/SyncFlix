"use strict";
(() => {
  // src/messages.ts
  var BRIDGE_PORT = "bridge";
  var PLAYER_PORT = "player";

  // src/background.ts
  var bridgePorts = /* @__PURE__ */ new Map();
  var playerPorts = /* @__PURE__ */ new Map();
  var activePlayerTab = null;
  var hostVideoUrl = null;
  function currentState() {
    const active = activePlayerTab !== null ? playerPorts.get(activePlayerTab) : void 0;
    return {
      status: active?.platform ? "connected" : "waiting",
      platform: active?.platform ?? null,
      version: chrome.runtime.getManifest().version,
      roomTabs: bridgePorts.size,
      playerTabs: playerPorts.size,
      videoId: active?.videoId ?? null,
      videoUrl: active?.videoUrl ?? null,
      hostVideoUrl
    };
  }
  function broadcastStateToBridges() {
    const msg = { type: "EXTENSION_STATE", payload: currentState() };
    bridgePorts.forEach((port) => port.postMessage(msg));
  }
  function pickAttachedPlayerTab() {
    for (const [tabId, entry] of playerPorts) {
      if (entry.platform) return tabId;
    }
    return null;
  }
  chrome.runtime.onConnect.addListener((port) => {
    const tabId = port.sender?.tab?.id;
    if (tabId === void 0) return;
    if (port.name === BRIDGE_PORT) {
      bridgePorts.set(tabId, port);
      port.onMessage.addListener((msg) => {
        if (msg.type === "GET_STATE") {
          port.postMessage({ type: "EXTENSION_STATE", payload: currentState() });
        } else if (msg.type === "SYNC_EVENT") {
          const target = activePlayerTab !== null ? playerPorts.get(activePlayerTab) : void 0;
          if (!target) {
            console.warn("[SyncFlix] dropped %s: no attached player tab", msg.payload.event);
            port.postMessage({ type: "EXTENSION_STATE", payload: currentState() });
            return;
          }
          target.port.postMessage(msg);
        } else if (msg.type === "HOST_VIDEO") {
          if (hostVideoUrl !== msg.payload.url) {
            hostVideoUrl = msg.payload.url;
            broadcastStateToBridges();
          }
        }
      });
      port.onDisconnect.addListener(() => {
        bridgePorts.delete(tabId);
      });
      return;
    }
    if (port.name === PLAYER_PORT) {
      playerPorts.set(tabId, { port, platform: null, videoId: null, videoUrl: null });
      port.onMessage.addListener((msg) => {
        const entry = playerPorts.get(tabId);
        if (!entry) return;
        if (msg.type === "ADAPTER_ATTACHED") {
          entry.platform = msg.payload.platform;
          entry.videoId = msg.payload.videoId;
          entry.videoUrl = msg.payload.videoUrl;
          activePlayerTab = tabId;
          broadcastStateToBridges();
        } else if (msg.type === "ADAPTER_LOST") {
          entry.platform = null;
          entry.videoId = null;
          entry.videoUrl = null;
          if (activePlayerTab === tabId) activePlayerTab = pickAttachedPlayerTab();
          broadcastStateToBridges();
        } else if (msg.type === "SYNC_EVENT") {
          if (tabId !== activePlayerTab) return;
          bridgePorts.forEach((bridge) => bridge.postMessage(msg));
        }
      });
      port.onDisconnect.addListener(() => {
        playerPorts.delete(tabId);
        if (activePlayerTab === tabId) {
          activePlayerTab = pickAttachedPlayerTab();
          broadcastStateToBridges();
        }
      });
    }
  });
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg?.type === "GET_STATE") {
      sendResponse(currentState());
    }
  });
})();
